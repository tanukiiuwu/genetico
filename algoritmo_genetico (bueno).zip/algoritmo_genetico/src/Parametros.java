import jade.core.Agent;

public class Parametros extends Agent {

    public void setup() {
        // Parámetros del algoritmo genético
        double tasaMutacion = 0.05;  // es el 5% por gen para mutarlo
        int tamañoPoblacion = 50;    // tamaño de población
        int numGeneraciones = 20;    // número de generaciones
        double tasaCrossover = 0.7;
        int tamañoDatos = 100;       // número de datos generados

        // Creación del algoritmo genético y ejecución
        Genetico ga = new Genetico(tasaMutacion, tamañoPoblacion, numGeneraciones, tasaCrossover, tamañoDatos);
        ga.ejecutar();  // Ejecutar el algoritmo genético
    }
}
