import jade.core.Runtime;
import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;

public class Main {
    public static void main(String[] args) {
        try {
            Runtime runtime = Runtime.instance();
            Profile profile = new ProfileImpl();
            profile.setParameter(Profile.MAIN_PORT, "1098");
            AgentContainer container = runtime.createMainContainer(profile);

            System.out.println("Creating agent 'parametros'...");
            AgentController agentController = container.createNewAgent("parametros", "Parametros", new Object[]{});

            System.out.println("Starting agent 'parametros'...");
            agentController.start();

            System.out.println("Agent container Main-Container@192.168.169.45 is ready.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
