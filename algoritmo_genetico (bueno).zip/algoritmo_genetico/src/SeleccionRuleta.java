import java.util.Random;

public class SeleccionRuleta {

    public static int seleccionar(double[] fitness) {
        int n = fitness.length;
        double fitnessTotal = 0.0;

        for (double f : fitness) {
            fitnessTotal += f;
        }

        if (fitnessTotal == 0) {
            throw new IllegalArgumentException("El fitness total no puede ser cero");
        }

        double[] probabilidadesAcumuladas = new double[n];
        probabilidadesAcumuladas[0] = fitness[0] / fitnessTotal;
        for (int i = 1; i < n; i++) {
            probabilidadesAcumuladas[i] = probabilidadesAcumuladas[i - 1] + (fitness[i] / fitnessTotal);
        }
        double r = Math.random();
        for (int i = 0; i < n; i++) {
            if (r <= probabilidadesAcumuladas[i]) {
                return i;
            }
        }

        return n - 1;  //si no se encontro pasar el cromosoma
    }
}
