public class Dataset {

    public double[] X;
    public double[] y;
    public double[] C;
    public int n;

    // Betas verdaderas
    private double beta0 = 2.0;  // Beta 0 verdadero
    private double beta1 = 1.5;  // Beta 1 verdadero

    public Dataset() {
        this.X = new double[]{1, 2, 3, 4, 5, 6, 7, 8, 9};
        this.y = new double[]{3, 6, 9, 12, 15, 18, 21, 24, 27};
        this.C = new double[]{66, 70, 62, 33, 55};
        this.n = X.length;
    }

    // Obtener betas verdaderas
    public double getBeta0() {
        return beta0;
    }

    public double getBeta1() {
        return beta1;
    }

    // Calcular 'y' utilizando betas verdaderas
    public void calcularY() {
        for (int i = 0; i < n; i++) {
            y[i] = beta0 + beta1 * X[i];
        }
    }
}

